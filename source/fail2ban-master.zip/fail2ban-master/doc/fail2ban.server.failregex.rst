fail2ban.server.failregex module
================================

.. automodule:: fail2ban.server.failregex
    :members:
    :undoc-members:
    :show-inheritance:
